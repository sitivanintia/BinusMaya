/* SESI MINI extension — MAIN-world bridge. Receives commands from content.js via postMessage and
 * drives the page scripts (auto-prompt, single-clip enforcer, video collector, MD attach). */
(() => {
  if (window.__sesiExtBridge) return; window.__sesiExtBridge = true;
  const post = m => { try { window.postMessage(Object.assign({ __sesi: true }, m), location.origin); } catch (_) {} };
  // inject.js / attach-md.js talk to the Android bridge; emulate it so the same files run unchanged.
  window.IDBridge = window.IDBridge || {
    onVideo: json => { try { post({ type: 'video', video: JSON.parse(json) }); } catch (_) {} },
    onAttached: () => post({ type: 'attached' })
  };
  window.addEventListener('message', ev => {
    if (ev.source !== window || !ev.data || ev.data.__sesi !== true || ev.data.type !== 'cmd') return;
    const { id, cmd, args = {} } = ev.data; let result;
    try {
      const ap = window.__sesiAutoPrompt, en = window.__whempySingleClip;
      switch (cmd) {
        case 'ping': result = { ok: true, autoPrompt: !!ap, enforcer: !!en, collector: !!window.__idreamsVideos }; break;
        case 'autoPrompt': {
          if (!ap) throw new Error('auto-prompt belum siap');
          const s = args.enabled ? ap.activate() : ap.deactivate();
          if (en) { en.cfg.enabled = en.cfg.aggressive = en.cfg.forceModel25 = !!args.enabled; en.cfg.duration = 30; }
          result = { ok: !!s.ready && s.enabled === !!args.enabled }; break;
        }
        case 'imageNote': { if (!ap) throw new Error('auto-prompt belum siap'); const s = ap.setImageNote(!!args.enabled); result = { ok: !!s.ready && s.imageNoteEnabled === !!args.enabled }; break; }
        case 'status': result = { autoPrompt: ap ? ap.status() : null, enforcer: en ? en.cfg.enabled : null }; break;
        case 'scan': { try { window.__idreamsScanDom?.(); } catch (_) {} result = { videos: window.__idreamsVideos?.() || [], pending: window.__idreamsPending?.() || 0 }; break; }
        case 'attach': result = window.__idreamsAttach ? window.__idreamsAttach(args.base64 || '', !!args.arm, args.name || '') : { ok: false, message: 'helper lampiran tidak ada' }; break;
        default: result = { ok: false, error: 'unknown cmd' };
      }
    } catch (e) { result = { ok: false, error: String((e && e.message) || e) }; }
    post({ type: 'reply', id, result });
  });
})();
window.__idreamsAttach = // Arms/disarms MD attachment. Dola creates its <input type=file> on demand when the user taps
// "Unggah File atau Gambar", so we intercept the next programmatic .click() on a file input and
// feed the bundled MD instead of opening the system picker. One-shot per activation.
(function (base64, arm, name) {
  if (!/(^|\.)dola\.com$/i.test(location.hostname)) return { ok: false, message: 'Buka dola.com terlebih dahulu.' };
  const filename = name || 'Introvert-Dreams-SKILL-v5.md';
  const S = (window.__idreamsArm = window.__idreamsArm || { armed: false, installed: false });
  S.armed = !!arm;
  if (!S.armed) return { ok: true, message: 'Nonaktif.' };
  S.file = () => new File([Uint8Array.from(atob(base64), c => c.charCodeAt(0))], filename, { type: 'text/markdown' });
  const feed = input => {
    try {
      const dt = new DataTransfer(); dt.items.add(S.file());
      input.files = dt.files;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      S.armed = false; try { window.IDBridge?.onAttached(); } catch (_) {}
      return true;
    } catch (_) { return false; }
  };
  if (!S.installed) {
    S.installed = true;
    const origClick = HTMLInputElement.prototype.click;
    HTMLInputElement.prototype.click = function () {
      if (S.armed && this.type === 'file' && !/^image\/\*$/.test(this.accept || '')) {
        // Defer so the site has finished wiring its change listener.
        setTimeout(() => feed(this), 0);
        return;
      }
      return origClick.call(this);
    };
    // Some builds use showPicker() instead of click().
    if (HTMLInputElement.prototype.showPicker) {
      const origPicker = HTMLInputElement.prototype.showPicker;
      HTMLInputElement.prototype.showPicker = function () {
        if (S.armed && this.type === 'file' && !/^image\/\*$/.test(this.accept || '')) { setTimeout(() => feed(this), 0); return; }
        return origPicker.call(this);
      };
    }
  }
  // If a suitable input already exists in the composer, use it immediately.
  const existing = [...document.querySelectorAll('input[type="file"]')].find(i => !i.disabled && !/^image\/\*$/.test(i.accept || ''));
  if (existing && feed(existing)) return { ok: true, message: 'File MD dilampirkan ke composer.' };
  return { ok: true, message: 'Aktif. Ketuk + → "Unggah File atau Gambar" — file MD akan terlampir otomatis.' };
});
;
