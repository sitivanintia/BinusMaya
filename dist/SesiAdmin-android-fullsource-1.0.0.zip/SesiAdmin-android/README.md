# SESI Admin — Android

APK admin untuk server lisensi SESI MINI (Google Apps Script + Sheet, kode server di `server/Code.gs`).

Fitur: buat key (jumlah, max perangkat, masa berlaku, label), nonaktifkan/aktifkan, lepas perangkat, ubah nama/max/expiry, hapus, salin/kirim key, monitoring (total, aktif, HP, online 24 jam, mati) dengan filter & pencarian.

## Setup server
Lihat `server/README.md` bagian "APK SESI Admin": tempel `Code.gs`, Run `setupAdmin()` (token di Execution log), deploy versi baru.

## Build
JDK 17 + Android SDK 34. URL server ada di `admin/src/main/res/values/values.xml` → `license_url`.
```
export ANDROID_HOME=/path/sdk
gradle :admin:assembleRelease
```
Hasil: `admin/build/outputs/apk/release/admin-release.apk` (debug-signed).

## Struktur
- `admin/src/main/java/com/introvertdreams/sesiadmin/AdminActivity.java` — UI (login token, daftar, aksi, buat key)
- `admin/src/main/java/com/introvertdreams/sesiadmin/Api.java` — klien HTTP ke Apps Script (POST → 302 → GET)
- `admin/src/main/res/` — ikon, tema, `license_url`
- `server/` — Code.gs + panduan
